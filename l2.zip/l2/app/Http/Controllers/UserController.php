<?php
namespace App\Http\Controllers;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class UserController extends Controller
{
	public $url='http://localhost/la/laravel/public';
	 public function index(){
	 	$data=User::paginate(4);
   		return view('user.index',['data'=>$data]);
   }
    public function index2(){
	 	$data=User::get();
   		return view('user.2s',['data'=>$data]);
   }
   public function add(){
   		return view('user.add');
   }
    public function checkin(){
         return view('user.checkin');
   }
    public function edit($id){
    	$data=User::find($id);
   		return view('user.edit',['data'=>$data]);
   }

   public function new(Request $request){
   		$input=$request->all();
   		$input=$request->except('_token');
   		
   		if($input['fen']-0>100 || $input['fen']-0<0){
   			  echo "<script>alert('The result is not correct');</script>"; die;
			
   		}
   		
   		if(strlen($input['title'])>10){
   			  echo "<script>alert('The title is less than 10 words');</script>"; die;
			
   		}
   	   $res=User::create($input);
   	   if($res){
   	   	return redirect('user/index');
   	   }else{
   	   	 return back();
   	   }
   }

   public function upd(Request $request){
   		$input=$request->all();
   		/*$input=$request->except('_token');*/
   		$u=[
   			'title'=>$input['title'],
   			'content'=>$input['content'],
   			'fen'=>$input['fen'],
   			'semester'=>$input['semester'],
   			'teacher'=>$input['teacher'],
   			'times'=>$input['times'],
   		];
   	  $res=DB::table("stclass")->where('id',$input['id'])->update($u);
   	   if($res){
   	   	return redirect('user/index');
   	   }else{
   	   	 return back();
   	   }
   }

    public function delete($id){
   		
   	  $res=DB::table("stclass")->where('id',$id)->delete();
   	   if($res){
   	   	return redirect('user/index');
   	   }else{
   	   	 return back();
   	   }
   }

  

    public function deleteall(Request $request){
    	$input=$request->except('_token');
   		foreach ($input['id'] as  $v) {
   		 $res=DB::table("stclass")->where('id',$v)->delete();
   		}
   	 
   	   if($res){
   	   	return redirect('user/index');
   	   }else{
   	   	 return back();
   	   }
   }


}
